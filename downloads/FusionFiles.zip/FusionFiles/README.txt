Here are the Fusion files for the organ keys. The only one that needs to be edited for a full set is BaldwinKeyParametrized.f3d. The others are ready as they are.
Below is a table containing the values for each parameter needed for each key:

Key	Left	Width
C	0mm	12.5mm
D	4.5mm	12.5mm
E	9.3mm	12.5mm
F	0mm	11.2mm
G	3.8mm	11.2mm
A	7mm	11.2mm
B	10.6mm	11.2mm

For the C, E, F, and B keys, the rear portion of the key lines up exactly with the side of the front of the key.
This causes Fusion to error out about a few of the fillets, but it's not an issue. Fusion will happily export the STLs for printing.
Leaving the offending fillets in place allows the model to be continuously modified via the parameters.